let countryData = ["India", "Denmark", "Norway", "Sweden"];
let statesData = {
    "India" : ["Punjab" , "Himachal","Kerala" , "Jammu"],
    "Denmark" : ["Arhus", "Bornholm", "Frederiksberg", "Fyn"],
    "Norway" : ["Akershus", "Finnmark", "Hedmark","Oslo"],
    "Sweden" : ["Blekinge", "Dalarnas", "Gavleborgs"]
};
let cityData = {
    "Punjab" : ["Mohali" , "Patiala" , "Chandigarh" , "Sangrur"],
    "Himachal" : ["Chamba" , "Hamirpur" , "kangra" , "Shimla"],
    "Kerala" : ["kannur" , "kollam" , "Trissur" , "Palakkad"],
    "Jammu" : ["Jammu" , "Doda" , "Rajouri"],
    "Arhus" : ["Aarhus" , "Lystrup", "Aarhus Municipality"],
    "Bornholm" : ["Gudhjem" , "Ribe" , "Soro"],
    "Frederiksberg" : ["Gorlev" , "Skaelskor"],
    "Fyn" : ["Copenhagen" , "Odense" , "Aalborg"],
    "Oslo" : ["Toyen" , "Ekeberg" , "Kongshavn" , "Sinsen"],
    "Hedmark" : ["Hamar" , "Kongsvinger" , "Elverum" , "Tynset"],
    "Finnmark" : ["Alta" , "Brevik" , "Brekstad" , "Askim"],
    "Akershus" : ["Algarheim" , "Ask" , "Asker" ],
    "Blekinge" : ["Dalarna" , "Halland" , "Backaryd"],
    "Dalarnas" : ["Haparanda" , "Helsingborg" , "Stockholm"],
    "Gavleborgs" : ["Arboga" , "Askersund" , "Arvika"]

}


// export default countryData;